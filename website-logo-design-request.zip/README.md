# Value Based Solutions — Website & Brand

<img src="public/brand/lockup-horizontal-dark.svg" alt="Value Based Solutions" width="320" />

Marketing website and visual identity for **Value Based Solutions**, a management
consulting firm in Cleveland, Ohio. The site is a single-page React application with a
custom brand system built around a new **Value Mark** logo.

**Live site:** https://wahedastana0-star.github.io/valuebasedsol/

---

## The Value Mark

The logo is made of two converging paths: **evidence** and **execution** meeting at a
single point — the decision that creates value. The gold edge rises above the baseline,
representing the value the work is meant to create. Navy and gold keep the mark
grounded and confident; the monogram stays legible from a favicon to a building sign.

All brand files are in [`public/brand`](public/brand) and described in
[`public/brand/README.md`](public/brand/README.md).

| File | Use |
| --- | --- |
| `app-tile.svg` | Favicon, app icon, social avatar |
| `value-mark.svg` | Mark on light backgrounds |
| `value-mark-inverse.svg` | Mark on dark backgrounds |
| `lockup-horizontal-{light,dark}.svg` | Primary signature (web header, documents, email) |
| `lockup-stacked-{light,dark}.svg` | Square formats (covers, slides, signage) |

The mark appears in the site header and footer. The footer links directly to downloadable SVG
lockups — **Brand mark** in the Company list and **Brand assets** in the legal row — so the
logo is always one click away without a separate spec page.

### Palette

| Name | Hex | Role |
| --- | --- | --- |
| Navy | `#081A38` | Primary surface and page canvas |
| Deep Navy | `#0C2246` | Secondary surface |
| Harbor | `#12305A` | Raised panels and quote band |
| Gold | `#C9A24B` | Accent, the raised edge |
| Soft Gold | `#B9AB88` | Muted body copy and labels |
| Pale Gold | `#EBD9A8` | Headline and body type on navy |

**Typography:** [Fraunces](https://fonts.google.com/specimen/Fraunces) for display,
[Inter](https://fonts.google.com/specimen/Inter) for interface and body. Both are loaded
from Google Fonts and licensed under the SIL Open Font License.

### Logo rules

- Keep one V-height of clear space around the mark.
- Never stretch, rotate, outline, or recolour the mark.
- Minimum size: 16 px digital, 8 mm print for the monogram.
- Use the supplied artwork rather than recreating the shapes.

---

## Motion & interaction

The site uses a small, reusable motion system built on CSS transitions plus
`IntersectionObserver` (no animation libraries). All of it is defined in
[`src/index.css`](src/index.css) and [`src/components/Motion.tsx`](src/components/Motion.tsx):

- **Masked hero entrance** — the headline rises line by line, with staggered supporting copy.
- **Pointer-reactive hero** — a gold spotlight and drifting Value Mark respond to the mouse.
- **Scroll reveals** — six directions (up, fade, left, right, scale, mask) with optional delays.
- **Word-by-word statements** — the perspective quote illuminates as it enters the viewport.
- **Parallax imagery** — the About photograph — a curved, gold-lit tower against a navy sky — moves gently behind its arch frame and unveils
  with a clip-path curtain.
- **Tilt + spotlight cards** — engagement briefs react to the pointer in 3D on mouse devices.
- **Micro-interactions** — sheen on buttons, the logo mark separating subtly on hover, an
  accordion icon that rotates into a minus, and a drawn check on form success.

Everything respects `prefers-reduced-motion: reduce`; pointer effects are disabled on touch
devices and motion-sensitive settings.

---

## Run locally

Requires **Node.js 20.19+ or 22.12+** (Node 22 is recommended).

```bash
npm install
npm run dev        # local development at http://localhost:5173
npm run build      # production build in dist/
npm run preview    # preview the production build
```

No environment variables or API keys are required.

---

## Put this on GitHub Pages

### Recommended: automatic deployment (included)

The repository includes [`.github/workflows/deploy.yml`](.github/workflows/deploy.yml),
which builds the site and publishes it to GitHub Pages on every push to `main`.

1. Copy this project into your repository (`wahedastana0-star/valuebasedsol`) and push to
   the `main` branch.
2. On GitHub, open **Settings → Pages → Build and deployment**.
3. Set **Source** to **GitHub Actions**. (If it is currently set to *Deploy from a branch*,
   switch it — do not serve the repository root, because the source `index.html` is a Vite
   entry file and is not the finished website.)
4. Open the **Actions** tab and wait for **Deploy website to GitHub Pages** to finish.
5. Visit https://wahedastana0-star.github.io/valuebasedsol/.

If your default branch is `master` instead of `main`, update the branch name at the top of
`.github/workflows/deploy.yml`.

### Manual alternative

Build the site, then publish the finished files to a separate folder or branch that does
**not** overwrite the source files:

```bash
npm run build
mkdir -p docs
cp -r dist/. docs/
```

Commit `docs/`, then set **Settings → Pages → Source** to *Deploy from a branch*, branch
`main`, folder `/docs`. The build is self-contained — JavaScript and CSS are inlined into
`dist/index.html` — so only the `dist`/`docs` output needs to be published.

> **Replacing your current site:** the old HTML/CSS/JS files can be removed once this
> project is in the repository. Do not copy the Vite `index.html` from the project root to
> a "docs" or "public" folder; always publish the generated `dist/` output.

---

## Project structure

```
index.html                  Page metadata, fonts, favicon, structured data
src/
  App.tsx                   Page composition
  main.tsx                  React entry
  index.css                 Design tokens, shared styles, motion
  lib/brand.ts              Logo geometry and palette
  hooks/useSite.ts          Scroll, reveal and navigation helpers
  components/
    Header.tsx              Sticky header and mobile menu
    Hero.tsx                Hero and value-lever marquee
    Services.tsx            Three consulting capabilities
    About.tsx               About section and perspective quote
    Approach.tsx            Interactive four-step approach
    Briefs.tsx              Client questions, short answers and topic filter
    Faq.tsx                 Accessible accordion
    Contact.tsx             Validated inquiry form
    Footer.tsx              Footer and secondary navigation
    Logo.tsx                Logo lockups, monogram and brand seal
    Icons.tsx               Consistent line icon set
    Motion.tsx              Reveal, stagger, word, tilt and parallax primitives
public/
  brand/                    Logo files and brand usage guide
  .nojekyll                 Keeps GitHub Pages from running Jekyll
.github/workflows/deploy.yml  GitHub Pages deployment
```

---

## Before you publish — two things to check

1. **The inquiry form is front-end only.** It validates entries and shows a confirmation,
   but it does not send an email or store data anywhere. Connect it to a form service
   (Formspree, Netlify Forms, Basin) or your own endpoint in
   `src/components/Contact.tsx` before treating it as a live lead form. Alternatively,
   direct visitors to the phone number.
2. **Contact details and legal copy.** The site uses the phone number **+1 216 401 5004**
   and Cleveland, Ohio as the location. The footer's "Privacy" link currently returns to the
   contact section. Replace it with a real privacy statement, and add an email address or
   social profile once you have one.

Page title, description, canonical URL, and structured business data are all in
`index.html`; update the canonical URL if the site moves to a custom domain.

---

## Credits

- Curved glass tower photograph by Arthur Swiffen via [Pexels](https://www.pexels.com/)
  (free to use under the Pexels license).
- Typefaces: Fraunces and Inter, Google Fonts (SIL OFL).
- Site and identity: prepared for Value Based Solutions. The name, marks, and brand assets
  are intended for use by Value Based Solutions only.

© Value Based Solutions. All rights reserved.
