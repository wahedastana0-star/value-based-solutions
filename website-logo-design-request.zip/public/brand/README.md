# The Value Mark

The identity for Value Based Solutions. Two converging paths meet at a single point:
evidence and execution resolving into the decision that creates value. The gold edge
rises above the baseline — the value the work is meant to create.

## Files

| File | Use |
| --- | --- |
| `app-tile.svg` | Favicon, app icon, social avatar. Navy tile with the gold mark. |
| `value-mark.svg` | Mark on light backgrounds. |
| `value-mark-inverse.svg` | Mark on dark backgrounds. |
| `lockup-horizontal-{light,dark}.svg` | Primary signature. Website header, documents, email. |
| `lockup-stacked-{light,dark}.svg` | Square formats. Covers, slides, signage. |

Everything is vector (SVG). Files stay editable and can be exported to PNG at any size.
The website uses the mark in its header and footer. Footer links — **Brand mark** and
**Brand assets** — point directly to the lockups below, so the logo can be downloaded
without leaving the page.

## Colour

| Token | Hex | Role |
| --- | --- | --- |
| Navy | `#081A38` | Primary surface and page canvas |
| Deep Navy | `#0C2246` | Secondary surface |
| Harbor | `#12305A` | Raised panels and cards |
| Gold | `#C9A24B` | Accent, the raised edge |
| Soft Gold | `#B9AB88` | Muted body copy and labels |
| Pale Gold | `#EBD9A8` | Headline and body type on navy |

## Typography

- **Fraunces** — display and headlines (light / 340 weight, italic for emphasis).
- **Inter** — interface labels, navigation, body copy.

## Clear space & minimum size

Keep one V-height of empty space on every side of the mark. Do not stretch, rotate, outline,
or recolour. Minimum size: 16 px digital, 8 mm print for the monogram.

## Usage

Use the supplied artwork. In HTML:

```html
<link rel="icon" type="image/svg+xml" href="/brand/app-tile.svg" />
<img src="/brand/lockup-horizontal-dark.svg" alt="Value Based Solutions" width="280" />
```

All identity assets in this folder are intended for Value Based Solutions.
