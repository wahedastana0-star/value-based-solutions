export const BRAND = {
  name: "Value Based Solutions",
  city: "Cleveland, Ohio",
  phone: "+1 216 401 5004",
  phoneHref: "tel:+12164015004",
  founded: "Cleveland-based. Nationally engaged.",
};

/** Geometry for the Value Mark: two paths converge into a V, the gold edge rising higher. */
export const MARK = {
  left: "M7 8H16L24 31V42Z",
  right: "M24 31L32 3H43L24 42Z",
  viewBox: "0 0 48 48",
};

export type Tone = "dark" | "light" | "mono";

export function markPalette(tone: Tone) {
  if (tone === "dark") return { left: "#EBD9A8", right: "#C9A24B" };
  if (tone === "light") return { left: "#081A38", right: "#C9A24B" };
  return { left: "currentColor", right: "currentColor" };
}
