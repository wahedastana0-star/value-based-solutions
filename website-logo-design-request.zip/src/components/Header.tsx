import { useEffect, useState } from "react";
import { cn } from "@/utils/cn";
import { LogoLockup } from "@/components/Logo";
import { ArrowUpRight, CloseIcon, MenuIcon, PhoneIcon, MapPinIcon } from "@/components/Icons";
import { useActiveSection, useBodyLock, useScrolled } from "@/hooks/useSite";
import { BRAND } from "@/lib/brand";

const NAV = [
  { id: "services", label: "What we do" },
  { id: "about", label: "About" },
  { id: "approach", label: "Approach" },
  { id: "briefs", label: "Engagement briefs" },
];

const SECTION_IDS = ["services", "about", "approach", "briefs", "faq", "contact"];

export function Header() {
  const scrolled = useScrolled(32);
  const active = useActiveSection(SECTION_IDS);
  const [open, setOpen] = useState(false);
  useBodyLock(open);

  useEffect(() => {
    const onKey = (event: KeyboardEvent) => {
      if (event.key === "Escape") setOpen(false);
    };
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, []);

  return (
    <>
      <header
        className={cn(
          "fixed inset-x-0 top-0 z-50 transition-all duration-500",
          scrolled
            ? "border-b border-gold/20 bg-ink/95 shadow-[0_12px_40px_-24px_rgba(0,0,0,0.65)] backdrop-blur-xl"
            : "border-b border-transparent bg-transparent",
        )}
      >
        <div className="shell flex h-[72px] items-center justify-between gap-4 sm:gap-6 md:h-[80px]">
          <a
            href="#top"
            aria-label="Value Based Solutions — back to top"
            className="group inline-flex min-h-[2.75rem] items-center py-1"
          >
            <LogoLockup
              tone="dark"
              markClassName="h-7 w-7 transition-transform duration-500 group-hover:scale-[1.06] sm:h-8 sm:w-8 md:h-9 md:w-9"
              className="gap-2 sm:gap-2.5 md:gap-3"
            />
          </a>

          <nav aria-label="Primary" className="hidden items-center gap-6 xl:flex xl:gap-7">
            {NAV.map((item) => {
              const isActive = active === item.id;
              return (
                <a
                  key={item.id}
                  href={`#${item.id}`}
                  className={cn(
                    "group relative whitespace-nowrap py-2 text-[0.688rem] font-medium uppercase tracking-[0.15em] transition-colors duration-300",
                    isActive
                      ? "text-gold-light"
                      : "text-frost/55 hover:text-gold-light",
                  )}
                >
                  {item.label}
                  <span
                    className={cn(
                      "absolute -bottom-0.5 left-0 h-px bg-gold transition-all duration-300",
                      isActive ? "w-full" : "w-0 group-hover:w-full",
                    )}
                  />
                </a>
              );
            })}
          </nav>

          <div className="flex items-center gap-3">
            <a
              href="#contact"
              className={cn(
                "btn btn-sm hidden md:inline-flex btn-gold",
              )}
            >
              Start a conversation
              <ArrowUpRight className="h-3.5 w-3.5" />
            </a>
            <button
              type="button"
              onClick={() => setOpen(true)}
              aria-label="Open menu"
              aria-expanded={open}
              className={cn(
                "inline-flex h-11 w-11 items-center justify-center rounded-full border transition-colors xl:hidden",
                "border-gold/30 text-gold-light hover:border-gold hover:bg-gold/10",
              )}
            >
              <MenuIcon className="h-5 w-5" />
            </button>
          </div>
        </div>
      </header>

      {open ? (
        <div
          role="dialog"
          aria-modal="true"
          aria-label="Site navigation"
          className="grain fixed inset-0 z-[70] flex flex-col overflow-y-auto bg-[#061530] text-frost"
        >
          <div className="relative z-10 flex min-h-full flex-col">
            <div className="shell flex h-[72px] items-center justify-between md:h-[80px]">
              <a href="#top" onClick={() => setOpen(false)} aria-label="Value Based Solutions">
                <LogoLockup tone="dark" />
              </a>
              <button
                type="button"
                onClick={() => setOpen(false)}
                aria-label="Close menu"
                className="inline-flex h-11 w-11 items-center justify-center rounded-full border border-gold/30 text-gold-light transition hover:border-gold hover:bg-gold/10"
              >
                <CloseIcon className="h-5 w-5" />
              </button>
            </div>

            <div className="shell flex flex-1 flex-col justify-center py-10">
              <p className="eyebrow mb-8 text-frost/45">Navigate</p>
              <nav aria-label="Mobile" className="flex flex-col">
                {NAV.concat({ id: "contact", label: "Contact" }).map((item, index) => (
                  <a
                    key={item.id}
                    href={`#${item.id}`}
                    onClick={() => setOpen(false)}
                    className="group flex items-baseline justify-between gap-6 border-b border-gold/10 py-4"
                    style={{ animation: "rise-in .5s var(--ease-out-soft) both", animationDelay: `${index * 55}ms` }}
                  >
                    <span className="flex items-baseline gap-4">
                      <span className="font-sans text-[0.59rem] uppercase tracking-[0.2em] text-gold">
                        {String(index + 1).padStart(2, "0")}
                      </span>
                      <span className="display text-[clamp(1.9rem,7vw,2.75rem)] text-frost transition-colors group-hover:text-gold-light">
                        {item.label}
                      </span>
                    </span>
                    <ArrowUpRight className="h-5 w-5 shrink-0 text-frost/35 transition group-hover:text-gold" />
                  </a>
                ))}
              </nav>
            </div>

            <div className="shell grid gap-4 border-t border-gold/10 py-7 text-sm text-frost/55 sm:grid-cols-2">
              <a href={BRAND.phoneHref} className="inline-flex items-center gap-2.5 transition hover:text-frost">
                <PhoneIcon className="h-4 w-4 text-gold" />
                {BRAND.phone}
              </a>
              <span className="inline-flex items-center gap-2.5">
                <MapPinIcon className="h-4 w-4 text-gold" />
                {BRAND.city}
              </span>
            </div>
          </div>
        </div>
      ) : null}
    </>
  );
}
