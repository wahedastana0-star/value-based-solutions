import { useRef, type CSSProperties, type PointerEvent } from "react";
import { ArrowDown, ArrowUpRight, TargetIcon } from "@/components/Icons";
import { BrandSeal } from "@/components/Logo";
import { MARK, BRAND } from "@/lib/brand";

const LEVERS = [
  "Revenue growth",
  "Pricing",
  "Margin",
  "Working capital",
  "Procurement spend",
  "Supplier terms",
  "Process cycle time",
  "Operating model",
  "Technology ROI",
];

const LENS = [
  {
    label: "Revenue",
    question: "Where is growth constrained — or value left on the table?",
    index: "01",
  },
  {
    label: "Profitability",
    question: "Which margins are leaking, and what protects them?",
    index: "02",
  },
  {
    label: "Cost",
    question: "What can be removed without weakening the business?",
    index: "03",
  },
];

function delay(ms: number) {
  return { "--d": `${ms}ms` } as CSSProperties;
}

export function Hero() {
  const sectionRef = useRef<HTMLElement>(null);

  function handlePointerMove(event: PointerEvent<HTMLElement>) {
    if (event.pointerType !== "mouse") return;
    const element = sectionRef.current;
    if (!element) return;
    if (window.matchMedia("(prefers-reduced-motion: reduce)").matches) return;

    const rect = element.getBoundingClientRect();
    const x = event.clientX - rect.left;
    const y = event.clientY - rect.top;

    element.style.setProperty("--px", `${x.toFixed(0)}px`);
    element.style.setProperty("--py", `${y.toFixed(0)}px`);
    element.style.setProperty("--mx", ((x / rect.width - 0.5) * 2).toFixed(3));
    element.style.setProperty("--my", ((y / rect.height - 0.5) * 2).toFixed(3));
  }

  return (
    <section
      id="top"
      ref={sectionRef}
      onPointerMove={handlePointerMove}
      className="hero grain relative overflow-hidden bg-ink text-frost"
    >
      <div className="pointer-events-none absolute inset-0 grid-lines opacity-70" aria-hidden="true" />
      <div className="hero-spot pointer-events-none absolute inset-0 hidden lg:block" aria-hidden="true" />
      <div
        className="pointer-events-none absolute -left-40 -top-40 h-[560px] w-[560px] rounded-full opacity-70 blur-3xl"
        style={{ background: "radial-gradient(circle, rgba(22,51,92,.8) 0%, transparent 68%)" }}
        aria-hidden="true"
      />
      <div
        className="pointer-events-none absolute -bottom-52 right-[-10%] h-[620px] w-[620px] rounded-full opacity-40 blur-3xl"
        style={{ background: "radial-gradient(circle, rgba(201,162,75,.42) 0%, transparent 70%)" }}
        aria-hidden="true"
      />

      <div
        className="hero-mark pointer-events-none absolute -right-20 top-20 hidden h-[520px] w-[520px] xl:block"
        aria-hidden="true"
      >
        <div className="drift h-full w-full text-frost/[0.055]">
          <svg viewBox={MARK.viewBox} className="h-full w-full" fill="currentColor">
            <path d={MARK.left} />
            <path d={MARK.right} />
          </svg>
        </div>
      </div>

      <div
        className="pointer-events-none absolute right-[14%] top-[30%] hidden h-2 w-2 rounded-full bg-gold/70 lg:block"
        aria-hidden="true"
      />
      <div
        className="pointer-events-none absolute bottom-[22%] left-[4%] hidden h-12 w-12 rounded-full border border-gold/25 lg:block"
        aria-hidden="true"
      />

      <div className="shell relative z-10 pb-10 pt-28 sm:pt-32 md:pb-14 md:pt-36 lg:pb-12 lg:pt-36 xl:pt-40">
        <div className="hero-fade flex flex-wrap items-center justify-between gap-4" style={delay(80)}>
          <p className="eyebrow text-frost/65">Management consulting · Cleveland, Ohio</p>
          <p className="hidden items-center gap-2 text-[0.65rem] uppercase tracking-[0.2em] text-frost/40 md:flex">
            <span className="relative inline-block h-1.5 w-1.5 rounded-full bg-gold pulse-ring" />
            {BRAND.founded}
          </p>
        </div>

        <h1 className="display mt-8 max-w-[16ch] text-[clamp(2.65rem,8.9vw,7rem)] text-frost md:mt-10">
          <span className="line-mask">
            <span className="line-inner" style={delay(150)}>
              Move the levers
            </span>
          </span>
          <span className="line-mask">
            <span className="line-inner" style={delay(290)}>
              that <em className="text-gold">matter.</em>
            </span>
          </span>
        </h1>

        <div className="mt-10 grid gap-10 border-t border-gold/15 pt-9 lg:mt-14 lg:grid-cols-12 lg:gap-12">
          <div className="lg:col-span-6 xl:col-span-5">
            <p
              className="hero-fade max-w-xl text-[0.975rem] leading-relaxed text-frost/70 md:text-[1.05rem]"
              style={delay(480)}
            >
              Value Based Solutions brings fact-based analysis, experienced practitioners,
              and tailored methodologies to the decisions that shape revenue,
              profitability, and cost.
            </p>
            <div className="hero-fade mt-8 flex flex-col gap-3 sm:flex-row" style={delay(580)}>
              <a href="#services" className="btn btn-gold">
                Explore our services
                <ArrowDown className="h-3.5 w-3.5" />
              </a>
              <a href="#contact" className="btn btn-ghost-light">
                Start a conversation
                <ArrowUpRight className="h-3.5 w-3.5" />
              </a>
            </div>
            <div
              className="hero-fade mt-9 flex flex-wrap items-center gap-x-5 gap-y-2 text-[0.65rem] uppercase tracking-[0.16em] text-frost/40"
              style={delay(680)}
            >
              <span>Evidence</span>
              <span className="h-px w-4 bg-gold/60" />
              <span>Alignment</span>
              <span className="h-px w-4 bg-gold/60" />
              <span>Execution</span>
            </div>
          </div>

          <div className="relative lg:col-span-6 lg:pl-6 xl:col-span-6 xl:col-start-7">
            <BrandSeal className="float-soft absolute -top-28 right-0 z-20 hidden h-20 w-20 text-gold-light/70 xl:block" />

            <div className="relative overflow-hidden rounded-2xl border border-gold/25 bg-[#0b2245] text-frost shadow-[0_40px_80px_-50px_rgba(0,0,0,0.85)]">
              <div className="flex items-center justify-between gap-3 border-b border-gold/20 px-4 py-3.5 sm:px-6 sm:py-4 md:px-7">
                <div className="flex items-center gap-2.5">
                  <TargetIcon className="h-3.5 w-3.5 text-gold" />
                  <span className="text-[0.65rem] font-semibold uppercase tracking-[0.19em] text-gold-light">
                    The value lens
                  </span>
                </div>
                <span className="font-mono text-[0.65rem] tracking-[0.14em] text-stone">01 / 03</span>
              </div>

              <div className="divide-y divide-gold/12">
                {LENS.map((item, index) => (
                  <div
                    key={item.label}
                    className="hero-fade group grid grid-cols-[auto_1fr_auto] items-start gap-3 px-4 py-4 sm:gap-4 sm:px-6 sm:py-5 transition-colors duration-300 hover:bg-gold/[0.06] md:px-7"
                    style={delay(760 + index * 95)}
                  >
                    <span className="pt-1 font-mono text-[0.65rem] tracking-[0.12em] text-gold">
                      {item.index}
                    </span>
                    <div>
                      <p className="font-display text-[1.3rem] leading-none tracking-[-0.02em] text-gold-light">
                        {item.label}
                      </p>
                      <p className="mt-2 max-w-[34ch] text-[0.75rem] leading-relaxed text-stone">
                        {item.question}
                      </p>
                    </div>
                    <ArrowUpRight className="mt-1 h-4 w-4 text-gold/35 transition-all duration-300 group-hover:translate-x-0.5 group-hover:-translate-y-0.5 group-hover:text-gold" />
                  </div>
                ))}
              </div>

              <div className="flex items-center justify-between gap-4 bg-ink px-6 py-4 text-frost md:px-7">
                <span className="text-[0.65rem] uppercase tracking-[0.17em] text-gold-light/70">
                  Every engagement ties back to a value lever
                </span>
                <svg viewBox="0 0 92 26" className="h-6 w-20 shrink-0" aria-hidden="true">
                  <path
                    d="M2 22 L22 18 L38 20 L56 11 L72 13 L90 3"
                    fill="none"
                    stroke="#C9A24B"
                    strokeWidth="1.4"
                    className="draw-line"
                  />
                  <circle cx="90" cy="3" r="2.4" fill="#C9A24B" />
                </svg>
              </div>
            </div>

            <div className="hero-fade mt-4 flex items-center justify-between gap-4 text-[0.65rem] uppercase tracking-[0.16em] text-frost/35" style={delay(1000)}>
              <span>Independent advisory</span>
              <span className="hidden sm:inline">Middle-market focus</span>
              <span>Nationally engaged</span>
            </div>
          </div>
        </div>

        <div className="hero-fade mt-12 hidden items-center gap-5 md:flex" style={delay(1120)}>
          <span className="whitespace-nowrap text-[0.65rem] uppercase tracking-[0.2em] text-frost/35">
            Scroll to explore
          </span>
          <span className="relative h-px w-full max-w-[180px] overflow-hidden bg-[#0b2245]/12">
            <span className="cue-dot absolute inset-y-0 left-0 w-14 bg-gold" />
          </span>
          <span className="h-px flex-1 bg-gold/10" />
          <span className="font-mono text-[0.65rem] tracking-[0.16em] text-frost/25">
            CLE · OH
          </span>
        </div>
      </div>
    </section>
  );
}

export function LeverMarquee() {
  const items = [...LEVERS, ...LEVERS];
  return (
    <div className="relative flex overflow-hidden border-y border-gold/15 bg-[#0b2245]">
      <div className="absolute inset-y-0 left-0 z-10 w-16 bg-linear-to-r from-[#0b2245] to-transparent" aria-hidden="true" />
      <div className="absolute inset-y-0 right-0 z-10 w-16 bg-linear-to-l from-[#0b2245] to-transparent" aria-hidden="true" />
      <div className="marquee-track items-center py-4 md:py-5">
        {items.map((lever, index) => (
          <span
            key={`${lever}-${index}`}
            className="flex shrink-0 items-center gap-6 pr-6 md:gap-8 md:pr-8"
            aria-hidden={index >= LEVERS.length}
          >
            <span className="whitespace-nowrap font-display text-[1rem] tracking-[-0.01em] text-frost/65 transition-colors duration-300 hover:text-gold md:text-[1.125rem]">
              {lever}
            </span>
            <svg viewBox="0 0 10 10" className="h-2 w-2 shrink-0 text-gold" fill="currentColor" aria-hidden="true">
              <path d="M5 0 6.1 3.9 10 5 6.1 6.1 5 10 3.9 6.1 0 5 3.9 3.9Z" />
            </svg>
          </span>
        ))}
      </div>
    </div>
  );
}
