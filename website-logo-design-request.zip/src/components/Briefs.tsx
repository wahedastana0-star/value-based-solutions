import { useState } from "react";
import { ArrowUpRight, PlusIcon } from "@/components/Icons";
import { Reveal } from "@/components/Motion";
import { cn } from "@/utils/cn";

type Topic = {
  id: string;
  label: string;
  questions: { q: string; a: string }[];
};

const TOPICS: Topic[] = [
  {
    id: "value",
    label: "Defining value",
    questions: [
      {
        q: "How do we know which costs are actually worth taking out?",
        a: "Start with the capability your strategy depends on. Spend that protects revenue, quality, or delivery speed is not waste. We separate that from spend that buys nothing, then size the opportunity before anyone commits.",
      },
      {
        q: "Can you build a business case our CFO and board will accept?",
        a: "Yes. The case is built from your own operational and financial data, with assumptions stated and sensitivity tested. No vendor claims and no round-number savings.",
      },
      {
        q: "How do you measure value after an engagement ends?",
        a: "We define the measures and baseline at the outset, then track against them through implementation. The handover includes the reporting you need to keep measuring without us.",
      },
    ],
  },
  {
    id: "sourcing",
    label: "Sourcing & cost",
    questions: [
      {
        q: "Where do we start if our spend data is fragmented?",
        a: "With a rapid spend baseline: consolidate invoices, contracts, and supplier data into one view. It typically takes a few weeks and usually reveals the top ten categories and contracts worth addressing first.",
      },
      {
        q: "Will you simply squeeze suppliers until margins break?",
        a: "No. We improve commercial terms without damaging the relationships that keep the business running. The best sourcing work gives both sides a reason to keep the agreement.",
      },
      {
        q: "Can you support a negotiation without running the whole process?",
        a: "Yes. We can prepare the analysis, benchmark, and negotiation plan, then step back and let your team lead. Support is scoped to what the team actually needs.",
      },
    ],
  },
  {
    id: "process",
    label: "Process & supply chain",
    questions: [
      {
        q: "Where should we look first when delays keep appearing?",
        a: "Map the end-to-end flow before fixing individual steps. Most delays sit at handoffs, approvals, or unclear ownership — not inside any one team's work.",
      },
      {
        q: "How do we avoid disruption while redesigning a process?",
        a: "Pilot in one area or one product line. Prove the change, measure the effect, and use what you learn to shape the wider rollout. Nothing gets switched off before it is understood.",
      },
    ],
  },
  {
    id: "technology",
    label: "Technology decisions",
    questions: [
      {
        q: "How do we choose between competing technology platforms?",
        a: "Evaluate against a weighted set of your requirements: functional fit, integration, total cost, implementation risk, and your team's capacity to run it. Structure the decision before the demos.",
      },
      {
        q: "We already own a tool nobody uses. What should we do?",
        a: "Diagnose before replacing it. Poor adoption is often a workflow, training, or ownership issue rather than a product problem. Fix that first, then decide whether the tool still fits.",
      },
    ],
  },
  {
    id: "working",
    label: "Working together",
    questions: [
      {
        q: "What does a typical engagement look like?",
        a: "Four stages: discover the decision, build a shared fact base, implement, and measure results. Scope and timeline are agreed after the first conversation — usually weeks, not quarters.",
      },
      {
        q: "How much of our team's time will you need?",
        a: "A senior sponsor and access to the people who know the work. We handle the analysis and administration; your team validates conclusions. We won't build a parallel organization to run the project.",
      },
      {
        q: "Do you work remotely, or only in person?",
        a: "We are based in Cleveland and work nationally — in person for workshops and key decision points, remote for analysis and working sessions. The mix is agreed with you.",
      },
    ],
  },
];

export function Briefs() {
  const [topic, setTopic] = useState(0);
  const [open, setOpen] = useState<string | null>(null);
  const active = TOPICS[topic];

  return (
    <section id="briefs" className="section-pad relative bg-paper py-16 sm:py-20 md:py-28">
      <div className="shell">
        <Reveal className="grid gap-7 border-b border-gold/15 pb-9 sm:gap-8 lg:grid-cols-12 lg:items-end lg:gap-12 lg:pb-12">
          <div className="lg:col-span-8">
            <p className="eyebrow text-stone">What clients ask · 04</p>
            <h2 className="display mt-5 max-w-[20ch] text-[clamp(2.15rem,5vw,4rem)]">
              The questions behind <em>the work.</em>
            </h2>
          </div>
          <div className="lg:col-span-4">
            <p className="max-w-sm text-[0.9375rem] leading-relaxed text-stone">
              The questions leaders actually bring to us, with short answers. If yours isn't
              here, ask it directly.
            </p>
          </div>
        </Reveal>

        {/* Topic filter */}
        <Reveal variant="fade" delay={100}>
          <div className="mt-7 flex flex-wrap gap-2 sm:mt-9" role="tablist" aria-label="Question topics">
            {TOPICS.map((item, index) => (
              <button
                key={item.id}
                type="button"
                role="tab"
                aria-selected={topic === index}
                onClick={() => {
                  setTopic(index);
                  setOpen(null);
                }}
                className={cn(
                  "inline-flex items-center gap-2 rounded-full border px-3.5 py-2 text-[0.7rem] font-medium transition-colors duration-300 sm:text-[0.75rem]",
                  topic === index
                    ? "border-gold bg-gold text-ink"
                    : "border-gold/25 text-frost/65 hover:border-gold/55 hover:text-gold-light",
                )}
              >
                <span className="font-mono text-[0.6rem] tracking-[0.1em] opacity-70">
                  {String(index + 1).padStart(2, "0")}
                </span>
                {item.label}
              </button>
            ))}
          </div>
        </Reveal>

        <div className="mt-7 grid gap-8 sm:mt-9 lg:grid-cols-12 lg:gap-12">
          <Reveal variant="fade" delay={120} className="lg:col-span-4">
            <div className="rounded-2xl border border-gold/25 bg-[#0b2245] p-6 sm:p-7">
              <p className="eyebrow text-gold/70">Didn't find your question?</p>
              <h3 className="mt-4 font-display text-[1.6rem] leading-[1.12] tracking-[-0.025em] text-gold-light sm:text-[1.8rem]">
                Bring us the decision in front of you.
              </h3>
              <p className="mt-3 text-[0.86rem] leading-relaxed text-stone">
                A short conversation usually tells us whether we can help — and what the
                first useful step would be.
              </p>
              <a href="#contact" className="btn btn-gold btn-sm mt-6">
                Ask a question
                <ArrowUpRight className="h-3.5 w-3.5" />
              </a>
              <div className="mt-6 flex items-center gap-3 border-t border-gold/15 pt-5">
                <span className="h-1 w-1 rounded-full bg-gold" />
                <p className="text-[0.65rem] uppercase leading-relaxed tracking-[0.12em] text-stone/70">
                  No obligation · Cleveland, Ohio
                </p>
              </div>
            </div>
          </Reveal>

          <div className="lg:col-span-8">
            <div key={active.id} className="rise-in border-t border-gold/15">
              {active.questions.map((item, index) => {
                const key = `${active.id}-${index}`;
                const isOpen = open === key;
                const panelId = `topic-panel-${key}`;
                const buttonId = `topic-button-${key}`;
                return (
                  <div key={key} className="faq-item border-b border-gold/15">
                    <h3>
                      <button
                        type="button"
                        id={buttonId}
                        aria-expanded={isOpen}
                        aria-controls={panelId}
                        onClick={() => setOpen(isOpen ? null : key)}
                        className="group flex w-full items-start justify-between gap-4 py-5 text-left sm:gap-6 sm:py-6"
                      >
                        <span className="flex min-w-0 items-baseline gap-3 sm:gap-4">
                          <span className="pt-0.5 font-mono text-[0.62rem] tracking-[0.1em] text-gold/70">
                            {String(index + 1).padStart(2, "0")}
                          </span>
                          <span
                            className={cn(
                              "faq-question font-display text-[1.05rem] leading-snug tracking-[-0.015em] transition-colors sm:text-[1.2rem]",
                              isOpen ? "text-gold-light" : "text-frost/80 group-hover:text-gold-light",
                            )}
                          >
                            {item.q}
                          </span>
                        </span>
                        <span
                          className={cn(
                            "faq-toggle mt-0.5 inline-flex h-9 w-9 shrink-0 items-center justify-center rounded-full border sm:h-10 sm:w-10",
                            isOpen
                              ? "is-open border-gold bg-gold text-ink"
                              : "border-gold/30 text-gold-light/70 group-hover:border-gold group-hover:text-gold-light",
                          )}
                          aria-hidden="true"
                        >
                          <PlusIcon className="h-3.5 w-3.5" />
                        </span>
                      </button>
                    </h3>
                    <div
                      id={panelId}
                      role="region"
                      aria-labelledby={buttonId}
                      className={cn(
                        "grid transition-[grid-template-rows,opacity] duration-500 ease-[cubic-bezier(.22,1,.36,1)]",
                        isOpen ? "grid-rows-[1fr] opacity-100" : "grid-rows-[0fr] opacity-0",
                      )}
                    >
                      <div className="overflow-hidden">
                        <p className="max-w-2xl pb-6 pr-2 text-[0.875rem] leading-relaxed text-stone sm:pl-9 sm:pr-10 md:pb-7">
                          {item.a}
                        </p>
                      </div>
                    </div>
                  </div>
                );
              })}
            </div>

            <Reveal
              variant="fade"
              delay={160}
              className="mt-6 flex flex-wrap items-center gap-x-5 gap-y-2 text-[0.65rem] uppercase tracking-[0.13em] text-stone/60"
            >
              <span className="inline-flex items-center gap-2">
                <span className="h-1 w-1 rounded-full bg-gold" />
                {active.label}
              </span>
              <span className="hidden h-3 w-px bg-gold/20 sm:block" />
              <span>Short answers · no jargon</span>
            </Reveal>
          </div>
        </div>
      </div>
    </section>
  );
}
