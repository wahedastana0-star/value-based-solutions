import { useState, type FormEvent } from "react";
import { ArrowUpRight, ChevronDownIcon, MapPinIcon, PhoneIcon } from "@/components/Icons";
import { Reveal } from "@/components/Motion";
import { BrandSeal } from "@/components/Logo";
import { BRAND } from "@/lib/brand";
import { cn } from "@/utils/cn";

type FormState = {
  name: string;
  email: string;
  company: string;
  interest: string;
  message: string;
};

type FieldName = keyof FormState;

const EMPTY: FormState = {
  name: "",
  email: "",
  company: "",
  interest: "",
  message: "",
};

const INTERESTS = [
  "Revenue growth",
  "Profitability & margin",
  "Cost & strategic sourcing",
  "Process & supply chain",
  "Technology strategy",
  "Something else",
];

export function Contact() {
  const [form, setForm] = useState<FormState>(EMPTY);
  const [errors, setErrors] = useState<Partial<Record<FieldName, string>>>({});
  const [submitted, setSubmitted] = useState(false);

  function update(field: FieldName, value: string) {
    setForm((prev) => ({ ...prev, [field]: value }));
    setErrors((prev) => {
      if (!prev[field]) return prev;
      const next = { ...prev };
      delete next[field];
      return next;
    });
  }

  function handleSubmit(event: FormEvent<HTMLFormElement>) {
    event.preventDefault();
    const next: Partial<Record<FieldName, string>> = {};
    if (form.name.trim().length < 2) next.name = "Please share your name.";
    if (!/^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/.test(form.email.trim()))
      next.email = "A valid work email helps us reply.";
    if (form.message.trim().length < 12)
      next.message = "A sentence or two about the decision in front of you.";

    setErrors(next);
    if (Object.keys(next).length > 0) {
      const first = Object.keys(next)[0];
      document.getElementById(`field-${first}`)?.focus();
      return;
    }
    setSubmitted(true);
  }

  function reset() {
    setForm(EMPTY);
    setErrors({});
    setSubmitted(false);
  }

  return (
    <section id="contact" className="section-pad grain relative overflow-hidden bg-ink py-16 text-frost sm:py-20 md:py-28">
      <div className="pointer-events-none absolute inset-0 grid-lines opacity-50" aria-hidden="true" />
      <div
        className="pointer-events-none absolute -left-40 bottom-0 h-[520px] w-[520px] rounded-full opacity-40 blur-3xl"
        style={{ background: "radial-gradient(circle, rgba(22,51,92,.8) 0%, transparent 70%)" }}
        aria-hidden="true"
      />

      <div className="shell relative z-10 grid gap-12 lg:grid-cols-12 lg:gap-16">
        <Reveal className="lg:col-span-5">
          <p className="eyebrow text-frost/45">Start a conversation · 06</p>
          <h2 className="display mt-5 max-w-[15ch] text-[clamp(2.2rem,5vw,4.25rem)]">
            The right decision starts with <em className="text-gold">the right question.</em>
          </h2>
          <p className="mt-6 max-w-md text-[0.9375rem] leading-relaxed text-frost/55">
            Tell us what you are working to improve. We will respond with a focused
            conversation about your priorities, the value at stake, and practical next steps.
          </p>

          <div className="mt-9 space-y-3">
            <a
              href={BRAND.phoneHref}
              className="group flex items-center gap-4 rounded-xl border border-gold/20 bg-gold/[0.04] p-4 transition-colors hover:border-gold/45 hover:bg-gold/[0.08]"
            >
              <span className="inline-flex h-10 w-10 items-center justify-center rounded-full border border-gold/35 bg-gold/[0.06] text-gold">
                <PhoneIcon className="h-4 w-4" />
              </span>
              <span className="flex-1">
                <span className="block text-[0.65rem] uppercase tracking-[0.16em] text-frost/40">
                  Direct line
                </span>
                <span className="mt-1 block font-display text-[1.25rem] tracking-[-0.01em] text-frost">
                  {BRAND.phone}
                </span>
              </span>
              <ArrowUpRight className="h-4 w-4 text-frost/35 transition-all group-hover:translate-x-0.5 group-hover:-translate-y-0.5 group-hover:text-gold" />
            </a>

            <div className="flex items-start gap-4 rounded-xl border border-gold/20 p-4">
              <span className="inline-flex h-10 w-10 shrink-0 items-center justify-center rounded-full border border-gold/30 text-gold">
                <MapPinIcon className="h-4 w-4" />
              </span>
              <span>
                <span className="block text-[0.65rem] uppercase tracking-[0.16em] text-frost/40">
                  Based in
                </span>
                <span className="mt-1 block text-[0.9rem] text-frost/85">{BRAND.city}</span>
                <span className="mt-0.5 block text-[0.75rem] text-frost/35">
                  Engagements across the United States
                </span>
              </span>
            </div>
          </div>

          <div className="mt-9 flex items-center gap-4">
            <BrandSeal className="hidden h-16 w-16 shrink-0 text-gold/70 sm:block" />
            <p className="max-w-[26ch] text-[0.688rem] uppercase leading-relaxed tracking-[0.13em] text-frost/35">
              Independent advisory. Experienced practitioners. Practical paths to value.
            </p>
          </div>
        </Reveal>

        <Reveal variant="scale" delay={120} className="lg:col-span-7">
          <div className="relative overflow-hidden rounded-2xl border border-gold/15 bg-gold/[0.03] p-6 shadow-[0_40px_80px_-60px_rgba(0,0,0,.9)] backdrop-blur-sm md:p-9">
            {submitted ? (
              <div className="rise-in flex min-h-[430px] flex-col items-start justify-center py-6">
                <span className="success-item inline-flex h-14 w-14 items-center justify-center rounded-full bg-gold text-ink" style={{ animationDelay: "80ms" }}>
                  <svg
                    viewBox="0 0 24 24"
                    className="check-draw h-6 w-6"
                    fill="none"
                    stroke="currentColor"
                    strokeWidth="1.8"
                    strokeLinecap="round"
                    strokeLinejoin="round"
                    aria-hidden="true"
                  >
                    <path d="m5 12 4.5 4.5L19 7" />
                  </svg>
                </span>
                <p className="success-item mt-7 text-[0.65rem] font-semibold uppercase tracking-[0.18em] text-gold" style={{ animationDelay: "200ms" }}>
                  Message received
                </p>
                <h3 className="success-item mt-3 font-display text-[clamp(2rem,4vw,2.8rem)] leading-[1.08] tracking-[-0.03em]" style={{ animationDelay: "300ms" }}>
                  Thank you, {form.name.trim().split(" ")[0] || "friend"}.
                </h3>
                <p className="success-item mt-4 max-w-md text-[0.9rem] leading-relaxed text-frost/55" style={{ animationDelay: "400ms" }}>
                  Your note is with our team. Expect a thoughtful reply within two business
                  days. If the matter is time-sensitive, call{" "}
                  <a href={BRAND.phoneHref} className="text-frost underline decoration-gold/60 underline-offset-4">
                    {BRAND.phone}
                  </a>
                  .
                </p>
                <button
                  type="button"
                  onClick={reset}
                  className="success-item btn btn-ghost-light mt-8"
                  style={{ animationDelay: "500ms" }}
                >
                  Send another message
                  <ArrowUpRight className="h-3.5 w-3.5" />
                </button>
              </div>
            ) : (
              <form onSubmit={handleSubmit} noValidate>
                <div className="flex items-center justify-between gap-4 border-b border-gold/12 pb-5">
                  <p className="text-[0.65rem] font-semibold uppercase tracking-[0.18em] text-gold-light/70">
                    A focused first conversation
                  </p>
                  <span className="font-mono text-[0.65rem] tracking-[0.1em] text-frost/30">
                    ALL FIELDS REQUIRED*
                  </span>
                </div>

                <div className="mt-6 grid gap-6 md:grid-cols-2">
                  <div>
                    <label className="field-label" htmlFor="field-name">
                      Your name *
                    </label>
                    <input
                      id="field-name"
                      name="name"
                      autoComplete="name"
                      value={form.name}
                      onChange={(event) => update("name", event.target.value)}
                      aria-invalid={Boolean(errors.name)}
                      aria-describedby={errors.name ? "error-name" : undefined}
                      placeholder="Alex Morgan"
                      className={cn("field", errors.name && "field-invalid")}
                    />
                    {errors.name ? (
                      <p id="error-name" className="mt-1.5 text-[0.688rem] text-[#E8B66A]">
                        {errors.name}
                      </p>
                    ) : null}
                  </div>

                  <div>
                    <label className="field-label" htmlFor="field-email">
                      Work email *
                    </label>
                    <input
                      id="field-email"
                      name="email"
                      type="email"
                      inputMode="email"
                      autoComplete="email"
                      value={form.email}
                      onChange={(event) => update("email", event.target.value)}
                      aria-invalid={Boolean(errors.email)}
                      aria-describedby={errors.email ? "error-email" : undefined}
                      placeholder="you@company.com"
                      className={cn("field", errors.email && "field-invalid")}
                    />
                    {errors.email ? (
                      <p id="error-email" className="mt-1.5 text-[0.688rem] text-[#E8B66A]">
                        {errors.email}
                      </p>
                    ) : null}
                  </div>

                  <div>
                    <label className="field-label" htmlFor="field-company">
                      Organization
                    </label>
                    <input
                      id="field-company"
                      name="company"
                      autoComplete="organization"
                      value={form.company}
                      onChange={(event) => update("company", event.target.value)}
                      placeholder="Company or institution"
                      className="field"
                    />
                  </div>

                  <div>
                    <label className="field-label" htmlFor="field-interest">
                      Where is the value?
                    </label>
                    <div className="relative">
                      <select
                        id="field-interest"
                        name="interest"
                        value={form.interest}
                        onChange={(event) => update("interest", event.target.value)}
                        className="field appearance-none pr-8"
                      >
                        <option value="">Select a focus area</option>
                        {INTERESTS.map((interest) => (
                          <option key={interest} value={interest}>
                            {interest}
                          </option>
                        ))}
                      </select>
                      <ChevronDownIcon className="pointer-events-none absolute right-1 top-3 h-4 w-4 text-frost/35" />
                    </div>
                  </div>
                </div>

                <div className="mt-6">
                  <label className="field-label" htmlFor="field-message">
                    What are you working to improve? *
                  </label>
                  <textarea
                    id="field-message"
                    name="message"
                    rows={4}
                    value={form.message}
                    onChange={(event) => update("message", event.target.value)}
                    aria-invalid={Boolean(errors.message)}
                    aria-describedby={errors.message ? "error-message" : undefined}
                    placeholder="The decision, challenge, or opportunity in front of you…"
                    className={cn("field resize-none", errors.message && "field-invalid")}
                  />
                  {errors.message ? (
                    <p id="error-message" className="mt-1.5 text-[0.688rem] text-[#E8B66A]">
                      {errors.message}
                    </p>
                  ) : null}
                </div>

                <div className="mt-7 flex flex-col items-stretch justify-between gap-4 sm:flex-row sm:items-center">
                  <p className="max-w-[34ch] text-[0.65rem] leading-relaxed text-frost/30">
                    Your details stay with Value Based Solutions. We use them only to respond
                    to your enquiry.
                  </p>
                  <button type="submit" className="btn btn-gold w-full sm:w-auto">
                    Send inquiry
                    <ArrowUpRight className="h-3.5 w-3.5" />
                  </button>
                </div>
              </form>
            )}
          </div>
        </Reveal>
      </div>
    </section>
  );
}
