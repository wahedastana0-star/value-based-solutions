import type { CSSProperties } from "react";
import { ArrowUpRight, CompassIcon, CpuIcon, FlowIcon } from "@/components/Icons";
import { Reveal } from "@/components/Motion";
import { cn } from "@/utils/cn";

const SERVICES = [
  {
    index: "I",
    title: "Strategic Sourcing & Cost Management",
    icon: CompassIcon,
    summary:
      "Bring clarity to spend, supplier relationships, commercial terms, and sourcing decisions — while protecting the capabilities the business depends on.",
    bullets: [
      "Direct and indirect spend analysis",
      "Category and sourcing strategy",
      "Supplier negotiation and collaboration",
    ],
    outcome: "Spend visibility · Commercial control",
  },
  {
    index: "II",
    title: "Process & Supply Chain Optimization",
    icon: FlowIcon,
    summary:
      "Examine how work moves across teams, partners, and systems to identify friction and design more effective ways of operating.",
    bullets: [
      "Current-state process assessment",
      "Workflow and operating-model design",
      "Customer and supplier collaboration",
    ],
    outcome: "Less friction · Stronger throughput",
  },
  {
    index: "III",
    title: "Technology Strategy & Delivery",
    icon: CpuIcon,
    summary:
      "Align technology choices with business priorities through structured evaluation, practical planning, and disciplined implementation support.",
    bullets: [
      "IT strategy and business alignment",
      "Software evaluation and selection",
      "Implementation planning and enablement",
    ],
    outcome: "Clear choices · Disciplined delivery",
  },
];

export function Services() {
  return (
    <section id="services" className="section-pad relative overflow-hidden bg-paper py-16 sm:py-20 md:py-28">
      <div className="shell">
        <Reveal className="grid gap-6 border-b border-gold/15 pb-9 sm:gap-8 lg:grid-cols-12 lg:gap-12 lg:pb-14">
          <div className="lg:col-span-7">
            <p className="eyebrow text-stone">What we do · 01</p>
            <h2 className="display mt-5 max-w-[17ch] text-[clamp(2.15rem,5vw,4rem)]">
              Consulting built around <em>business value.</em>
            </h2>
          </div>
          <div className="flex flex-col items-start justify-end gap-6 lg:col-span-5">
            <p className="max-w-md text-[0.9375rem] leading-relaxed text-stone">
              Our capabilities connect commercial decisions, operational performance, and
              technology investments to the outcomes your organization is working to improve.
            </p>
            <a
              href="#contact"
              className="group inline-flex items-center gap-2.5 border-b border-gold/40 pb-1.5 text-[0.688rem] font-semibold uppercase tracking-[0.15em] text-gold-light transition hover:border-gold hover:text-gold"
            >
              Discuss a challenge
              <ArrowUpRight className="h-3.5 w-3.5 transition-transform duration-300 group-hover:translate-x-0.5 group-hover:-translate-y-0.5" />
            </a>
          </div>
        </Reveal>

        <div className="border-b border-gold/15">
          {SERVICES.map((service, i) => {
            const Icon = service.icon;
            return (
              <div
                key={service.title}
                className={cn(
                  "service-row reveal group relative grid gap-6 border-t border-gold/15 py-9 md:gap-8 md:py-12 lg:grid-cols-12 lg:gap-10",
                  i === 0 && "border-t-0",
                )}
                data-reveal="up"
                style={{ "--reveal-delay": `${i * 110}ms` } as CSSProperties}
              >
                <span
                  className="absolute left-0 top-0 hidden h-full w-[2px] origin-top scale-y-0 bg-gold transition-transform duration-500 group-hover:scale-y-100 lg:block"
                  aria-hidden="true"
                />
                <div className="flex items-start gap-5 lg:col-span-5 lg:pl-7">
                  <span className="mt-1 w-7 shrink-0 font-display text-[0.9rem] italic text-gold">
                    {service.index}
                  </span>
                  <div>
                    <div className="service-icon mb-4 inline-flex h-10 w-10 items-center justify-center rounded-full border border-gold/12 bg-[#0b2245] text-frost group-hover:border-gold group-hover:bg-ink group-hover:text-frost">
                      <Icon className="h-[1.15rem] w-[1.15rem]" />
                    </div>
                    <h3 className="service-title max-w-[20ch] font-display text-[1.45rem] leading-[1.12] tracking-[-0.025em] text-gold-light sm:text-[1.7rem] lg:text-[1.9rem]">
                      {service.title}
                    </h3>
                  </div>
                </div>

                <div className="lg:col-span-4">
                  <p className="max-w-md text-[0.9rem] leading-relaxed text-stone">{service.summary}</p>
                  <p className="mt-6 text-[0.65rem] uppercase tracking-[0.15em] text-gold">
                    {service.outcome}
                  </p>
                </div>

                <div className="lg:col-span-3">
                  <ul className="space-y-3">
                    {service.bullets.map((bullet) => (
                      <li key={bullet} className="flex items-start gap-3 text-[0.83rem] leading-snug text-frost/70">
                        <span className="mt-[0.45rem] h-1 w-1 shrink-0 rounded-full bg-gold transition-transform duration-300 group-hover:translate-x-1 group-hover:scale-125" />
                        {bullet}
                      </li>
                    ))}
                  </ul>
                  <a
                    href="#contact"
                    className="mt-6 inline-flex items-center gap-2 text-[0.65rem] font-semibold uppercase tracking-[0.15em] text-stone/70 transition group-hover:text-gold"
                  >
                    Start a conversation
                    <ArrowUpRight className="h-3 w-3 transition-transform duration-300 group-hover:translate-x-0.5 group-hover:-translate-y-0.5" />
                  </a>
                </div>
              </div>
            );
          })}
        </div>
      </div>
    </section>
  );
}
