import {
  useEffect,
  useRef,
  type CSSProperties,
  type ElementType,
  type PointerEvent,
  type ReactNode,
} from "react";
import { cn } from "@/utils/cn";

type RevealVariant = "up" | "fade" | "left" | "right" | "scale" | "mask";

type RevealProps = {
  children: ReactNode;
  className?: string;
  variant?: RevealVariant;
  delay?: number;
  as?: ElementType;
};

/** Scroll-triggered reveal. The observer in useRevealOnScroll adds `is-visible`. */
export function Reveal({
  children,
  className,
  variant = "up",
  delay = 0,
  as = "div",
}: RevealProps) {
  const Tag = as;
  return (
    <Tag
      className={cn("reveal", className)}
      data-reveal={variant}
      style={{ "--reveal-delay": `${delay}ms` } as CSSProperties}
    >
      {children}
    </Tag>
  );
}

type StaggerProps = {
  children: ReactNode;
  className?: string;
  delay?: number;
  as?: ElementType;
};

/** Container whose direct children reveal one after another. */
export function Stagger({ children, className, delay = 0, as = "div" }: StaggerProps) {
  const Tag = as;
  return (
    <Tag
      className={className}
      data-stagger=""
      style={{ "--stagger-delay": `${delay}ms` } as CSSProperties}
    >
      {children}
    </Tag>
  );
}

type Word = { text: string; accent?: boolean };

/** A quote or statement that illuminates word by word as it enters the viewport. */
export function WordReveal({ words, className }: { words: Word[]; className?: string }) {
  return (
    <span data-words="" className={className}>
      {words.map((word, index) => (
        <span key={`${word.text}-${index}`}>
          <span
            className={cn("word", word.accent && "accent")}
            style={{ "--i": index } as CSSProperties}
          >
            {word.text}
          </span>{" "}
        </span>
      ))}
    </span>
  );
}

type TiltCardProps = {
  children: ReactNode;
  className?: string;
  max?: number;
};

/** Subtle pointer-driven tilt with a gold spotlight. Disabled on touch / reduced motion. */
export function TiltCard({ children, className, max = 4 }: TiltCardProps) {
  const ref = useRef<HTMLDivElement>(null);

  function handleMove(event: PointerEvent<HTMLDivElement>) {
    const element = ref.current;
    if (!element || event.pointerType !== "mouse") return;
    if (window.matchMedia("(prefers-reduced-motion: reduce)").matches) return;

    const rect = element.getBoundingClientRect();
    const x = (event.clientX - rect.left) / rect.width;
    const y = (event.clientY - rect.top) / rect.height;

    element.style.setProperty("--ry", `${((x - 0.5) * max * 2).toFixed(2)}deg`);
    element.style.setProperty("--rx", `${((y - 0.5) * -max * 2).toFixed(2)}deg`);
    element.style.setProperty("--mx", `${(x * 100).toFixed(1)}%`);
    element.style.setProperty("--my", `${(y * 100).toFixed(1)}%`);
  }

  function reset() {
    const element = ref.current;
    if (!element) return;
    element.style.setProperty("--ry", "0deg");
    element.style.setProperty("--rx", "0deg");
  }

  return (
    <div
      ref={ref}
      className={cn("tilt-card", className)}
      onPointerMove={handleMove}
      onPointerLeave={reset}
    >
      {children}
    </div>
  );
}

type ParallaxProps = {
  children: ReactNode;
  className?: string;
  strength?: number;
  scale?: number;
};

/** Slow scroll parallax for imagery. */
export function ParallaxLayer({ children, className, strength = 16, scale = 1.12 }: ParallaxProps) {
  const ref = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const element = ref.current;
    if (!element) return;
    if (window.matchMedia("(prefers-reduced-motion: reduce)").matches) return;

    let frame = 0;

    const update = () => {
      frame = 0;
      const rect = element.getBoundingClientRect();
      const viewport = window.innerHeight || 1;
      const progress = (rect.top + rect.height / 2 - viewport / 2) / viewport;
      element.style.setProperty("--shift", `${(-progress * strength).toFixed(2)}px`);
    };

    const request = () => {
      if (!frame) frame = window.requestAnimationFrame(update);
    };

    update();
    window.addEventListener("scroll", request, { passive: true });
    window.addEventListener("resize", request);

    return () => {
      if (frame) window.cancelAnimationFrame(frame);
      window.removeEventListener("scroll", request);
      window.removeEventListener("resize", request);
    };
  }, [strength]);

  return (
    <div ref={ref} className={cn("absolute inset-0 overflow-hidden", className)} aria-hidden="true">
      <div className="parallax-inner h-full w-full" style={{ "--scale": scale } as CSSProperties}>
        {children}
      </div>
    </div>
  );
}
