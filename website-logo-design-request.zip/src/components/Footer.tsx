import { ArrowUpRight, DownloadIcon, MapPinIcon, PhoneIcon } from "@/components/Icons";
import { LogoLockup, LogoMark } from "@/components/Logo";
import { BRAND } from "@/lib/brand";

const EXPLORE = [
  { label: "What we do", href: "#services" },
  { label: "Our approach", href: "#approach" },
  { label: "About us", href: "#about" },
  { label: "Engagement briefs", href: "#briefs" },
];

const COMPANY = [
  { label: "Common questions", href: "#faq" },
  { label: "Start a conversation", href: "#contact" },
];

export function Footer() {
  return (
    <footer className="relative overflow-hidden border-t border-gold/25 bg-[#061530] pb-8 pt-16 text-frost">
      <div className="shell">
        <div className="grid gap-12 border-b border-gold/10 pb-12 lg:grid-cols-12">
          <div className="lg:col-span-5">
            <a href="#top" aria-label="Value Based Solutions — back to top" className="group inline-flex">
              <LogoLockup tone="dark" size="md" />
            </a>
            <p className="display mt-7 max-w-[15ch] text-[1.9rem] leading-[1.08] text-frost/90 md:text-[2.2rem]">
              Clear thinking.
              <br />
              <em className="text-gold">Meaningful value.</em>
            </p>
            <div className="mt-6 flex items-center gap-3 sm:mt-7">
              <LogoMark tone="dark" className="h-4 w-4" />
              <p className="text-[0.65rem] uppercase tracking-[0.16em] text-frost/35">
                Revenue · Profitability · Cost
              </p>
            </div>
          </div>

          <div className="grid gap-8 sm:grid-cols-2 lg:col-span-4">
            <div>
              <p className="text-[0.65rem] font-semibold uppercase tracking-[0.18em] text-frost/35">
                Explore
              </p>
              <ul className="mt-2 space-y-0.5 sm:mt-3">
                {EXPLORE.map((link) => (
                  <li key={link.href}>
                    <a
                      href={link.href}
                      className="group inline-flex min-h-[2.25rem] items-center gap-2 py-1 text-[0.85rem] text-frost/60 transition-colors hover:text-frost"
                    >
                      {link.label}
                      <ArrowUpRight className="h-3 w-3 opacity-0 transition-opacity group-hover:opacity-60" />
                    </a>
                  </li>
                ))}
              </ul>
            </div>
            <div>
              <p className="text-[0.65rem] font-semibold uppercase tracking-[0.18em] text-frost/35">
                Company
              </p>
              <ul className="mt-2 space-y-0.5 sm:mt-3">
                {COMPANY.map((link) => (
                  <li key={link.href}>
                    <a
                      href={link.href}
                      className="group inline-flex min-h-[2.25rem] items-center gap-2 py-1 text-[0.85rem] text-frost/60 transition-colors hover:text-frost"
                    >
                      {link.label}
                      <ArrowUpRight className="h-3 w-3 opacity-0 transition-opacity group-hover:opacity-60" />
                    </a>
                  </li>
                ))}
                <li>
                  <a
                    href="brand/lockup-horizontal-dark.svg"
                    download="value-based-solutions-logo.svg"
                    className="group inline-flex min-h-[2.25rem] items-center gap-2 py-1 text-[0.85rem] text-frost/60 transition-colors hover:text-frost"
                  >
                    Brand mark
                    <DownloadIcon className="h-3 w-3 opacity-0 transition-opacity group-hover:opacity-60" />
                  </a>
                </li>
              </ul>
            </div>
          </div>

          <div className="lg:col-span-3">
            <p className="text-[0.65rem] font-semibold uppercase tracking-[0.18em] text-frost/35">
              Contact
            </p>
            <div className="mt-4 flex flex-col gap-2">
              <a
                href={BRAND.phoneHref}
                className="inline-flex min-h-[2.25rem] items-center gap-2.5 py-1 text-[0.9rem] text-frost/75 transition-colors hover:text-frost"
              >
                <PhoneIcon className="h-3.5 w-3.5 shrink-0 text-gold" />
                {BRAND.phone}
              </a>
              <p className="flex items-center gap-2.5 text-[0.9rem] text-frost/55">
                <MapPinIcon className="h-3.5 w-3.5 shrink-0 text-gold" />
                {BRAND.city}
              </p>
            </div>
            <a href="#contact" className="btn btn-ghost-light btn-sm mt-6">
              Start a conversation
              <ArrowUpRight className="h-3.5 w-3.5" />
            </a>
            <p className="mt-5 max-w-[24ch] text-[0.65rem] leading-relaxed text-frost/30">
              Management consulting for the decisions that shape revenue, profitability, and cost.
            </p>
          </div>
        </div>

        <div className="flex flex-col items-start justify-between gap-4 pt-6 sm:flex-row sm:items-center">
          <p className="text-[0.65rem] tracking-[0.02em] text-frost/30">
            © {new Date().getFullYear()} Value Based Solutions. All rights reserved.
          </p>
          <div className="flex flex-wrap items-center gap-x-5 gap-y-2 text-[0.65rem] uppercase tracking-[0.14em] text-frost/30">
            <a
              href="brand/lockup-horizontal-dark.svg"
              download="value-based-solutions-logo.svg"
              className="transition-colors hover:text-frost/70"
            >
              Brand assets
            </a>
            <span className="hidden h-3 w-px bg-[#0b2245]/15 sm:block" />
            <a href="#contact" className="transition-colors hover:text-frost/70">
              Privacy
            </a>
            <span className="hidden h-3 w-px bg-[#0b2245]/15 sm:block" />
            <a href="#top" className="inline-flex items-center gap-1.5 transition-colors hover:text-frost/70">
              Back to top
              <ArrowUpRight className="h-3 w-3 -rotate-45" />
            </a>
          </div>
        </div>
      </div>
    </footer>
  );
}
