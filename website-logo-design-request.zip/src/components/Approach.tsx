import { useState } from "react";
import { ArrowUpRight, CheckIcon } from "@/components/Icons";
import { Reveal } from "@/components/Motion";
import { cn } from "@/utils/cn";

const STEPS = [
  {
    number: "01",
    title: "Discover",
    kicker: "Understand the business",
    description:
      "We begin with the decision in front of you — your priorities, constraints, stakeholders, and the outcomes you are working to improve.",
    deliverables: ["Leadership alignment", "Priority value levers", "Engagement scope"],
  },
  {
    number: "02",
    title: "Analyze",
    kicker: "Build the fact base",
    description:
      "We gather operational, financial, market, supplier, and technology evidence to establish a shared view of where the greatest value can be created or protected.",
    deliverables: ["Spend and process data", "Opportunity assessment", "Fact-based business case"],
  },
  {
    number: "03",
    title: "Implement",
    kicker: "Turn decision into action",
    description:
      "We evaluate alternatives, test assumptions, and translate the chosen path into a practical roadmap with clear ownership, actions, and implementation considerations.",
    deliverables: ["Tailored solution design", "Clear roadmap", "Execution support"],
  },
  {
    number: "04",
    title: "Measure results",
    kicker: "Prove the value",
    description:
      "We evaluate outcomes, track progress, and identify where continued improvement will sustain the value delivered.",
    deliverables: ["Outcome measurement", "Progress reporting", "Continuous improvement"],
  },
];

export function Approach() {
  const [active, setActive] = useState(0);
  const step = STEPS[active];

  return (
    <section id="approach" className="section-pad relative overflow-hidden bg-haze py-16 sm:py-20 md:py-28">
      <div className="pointer-events-none absolute inset-x-0 top-0 h-px bg-gold/20" />
      <div className="shell">
        <Reveal className="grid gap-8 lg:grid-cols-12 lg:items-end lg:gap-12">
          <div className="lg:col-span-8">
            <p className="eyebrow text-stone">How we work · 03</p>
            <h2 className="display mt-5 max-w-[18ch] text-[clamp(2.15rem,5vw,4rem)]">
              From complex question to <em>confident action.</em>
            </h2>
          </div>
          <div className="lg:col-span-4">
            <p className="max-w-sm text-[0.9375rem] leading-relaxed text-stone">
              A clear, structured approach that turns business challenges into meaningful
              results — shaped around the decision at hand.
            </p>
          </div>
        </Reveal>

        <div className="mt-9 grid gap-8 sm:mt-12 lg:grid-cols-12 lg:gap-12">
          <Reveal className="lg:col-span-5">
            <div className="relative border-b border-gold/20">
              <span
                className="pointer-events-none absolute bottom-[42px] left-[26px] top-[42px] w-px bg-gold/20 md:left-[30px]"
                aria-hidden="true"
              />
              <span
                className="pointer-events-none absolute left-[22px] top-[42px] w-px bg-gold transition-[height] duration-700 ease-[cubic-bezier(.22,1,.36,1)]"
                style={{ height: `calc((100% - 84px) * ${(active + 1) / STEPS.length})` }}
                aria-hidden="true"
              />

              {STEPS.map((item, index) => {
                const isActive = index === active;
                return (
                  <button
                    key={item.number}
                    type="button"
                    onClick={() => setActive(index)}
                    aria-pressed={isActive}
                    className={cn(
                      "group relative z-10 flex w-full items-center gap-5 border-t border-gold/15 px-1 py-5 text-left transition-all duration-300 md:px-2",
                      isActive ? "text-gold-light" : "text-frost/40 hover:text-frost/75",
                    )}
                  >
                    <span
                      className={cn(
                        "relative flex h-11 w-11 shrink-0 items-center justify-center rounded-full border font-mono text-[0.688rem] tracking-[0.08em] transition-all duration-500",
                        isActive
                          ? "scale-105 border-gold bg-ink text-frost shadow-[0_10px_24px_-16px_rgba(8,26,56,.9)]"
                          : "border-gold/20 bg-haze text-frost/50 group-hover:border-gold/40",
                      )}
                    >
                      {item.number}
                    </span>
                    <span className="flex-1">
                      <span className="block font-display text-[1.4rem] leading-none tracking-[-0.02em] sm:text-[1.55rem]">
                        {item.title}
                      </span>
                      <span
                        className={cn(
                          "mt-1.5 block text-[0.65rem] uppercase tracking-[0.14em] transition-colors duration-300",
                          isActive ? "text-gold" : "text-stone/60",
                        )}
                      >
                        {item.kicker}
                      </span>
                    </span>
                    <span
                      className={cn(
                        "h-px w-6 shrink-0 bg-gold/25 transition-all duration-500",
                        isActive ? "w-10 bg-gold" : "group-hover:w-8",
                      )}
                    />
                  </button>
                );
              })}
            </div>
            <p className="mt-6 max-w-sm text-[0.75rem] leading-relaxed text-stone">
              Each engagement is shaped around the available evidence and the value the
              organization needs to create or protect.
            </p>
          </Reveal>

          <Reveal variant="scale" delay={140} className="lg:col-span-7">
            <div className="relative flex h-full min-h-[340px] flex-col justify-between overflow-hidden rounded-2xl border border-gold/25 bg-[#0b2245] p-5 shadow-[0_30px_60px_-50px_rgba(0,0,0,.8)] sm:min-h-[380px] sm:p-7 md:p-10">
              <span
                key={`num-${active}`}
                className="rise-in pointer-events-none absolute -right-4 -top-10 select-none font-display text-[8rem] leading-none tracking-[-0.06em] text-gold/[0.08] sm:-top-14 sm:text-[11rem] md:text-[13rem]"
                aria-hidden="true"
              >
                {step.number}
              </span>

              <div key={active} className="rise-in relative">
                <div className="flex items-center justify-between gap-3">
                  <p className="eyebrow text-gold">{step.kicker}</p>
                  <span className="shrink-0 whitespace-nowrap font-mono text-[0.65rem] tracking-[0.16em] text-stone/70">
                    {step.number} / 04
                  </span>
                </div>
                <h3 className="display mt-5 text-[clamp(1.8rem,4vw,3rem)] sm:mt-7">{step.title}</h3>
                <p className="mt-5 max-w-xl text-[0.9375rem] leading-relaxed text-stone">
                  {step.description}
                </p>

                <div className="mt-8">
                  <p className="text-[0.65rem] font-semibold uppercase tracking-[0.17em] text-gold-light/70">
                    What this looks like
                  </p>
                  <div className="mt-4 flex flex-wrap gap-2.5">
                    {step.deliverables.map((item, index) => (
                      <span
                        key={item}
                        className="rise-in inline-flex items-center gap-2 rounded-full border border-gold/12 bg-[#12305a] px-3.5 py-2 text-[0.75rem] text-frost/80"
                        style={{ animationDelay: `${120 + index * 90}ms` }}
                      >
                        <CheckIcon className="h-3 w-3 text-gold" />
                        {item}
                      </span>
                    ))}
                  </div>
                </div>
              </div>

              <div className="relative mt-10 flex items-center justify-between gap-4 border-t border-gold/15 pt-5">
                <div className="flex gap-1.5" aria-hidden="true">
                  {STEPS.map((item, index) => (
                    <span
                      key={item.number}
                      className={cn(
                        "h-1 rounded-full transition-all duration-500",
                        index === active ? "w-8 bg-gold" : "w-3 bg-gold/20",
                      )}
                    />
                  ))}
                </div>
                <a
                  href="#contact"
                  className="group inline-flex items-center gap-2 text-[0.65rem] font-semibold uppercase tracking-[0.15em] text-gold-light transition hover:text-gold"
                >
                  Start a conversation
                  <ArrowUpRight className="h-3.5 w-3.5 transition-transform duration-300 group-hover:translate-x-0.5 group-hover:-translate-y-0.5" />
                </a>
              </div>
            </div>
          </Reveal>
        </div>
      </div>
    </section>
  );
}
