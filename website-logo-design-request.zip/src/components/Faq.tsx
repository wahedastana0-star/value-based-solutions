import { useState } from "react";
import { ArrowUpRight, PlusIcon } from "@/components/Icons";
import { Reveal } from "@/components/Motion";
import { cn } from "@/utils/cn";

const QUESTIONS = [
  {
    question: "What kinds of business challenges do you help with?",
    answer:
      "We help businesses improve strategic sourcing, cost management, processes, supply chain performance, and technology strategy and delivery. Each engagement is connected to the value levers that matter most to the organization.",
  },
  {
    question: "How do you approach an engagement?",
    answer:
      "We start by defining the decision and the value at stake, then build a shared fact base, design a tailored solution, and support disciplined execution. Progress is measured against the outcomes we agreed to pursue.",
  },
  {
    question: "What results can we expect?",
    answer:
      "Our focus is on business outcomes that matter — improving performance, managing costs, and creating measurable value. Specific objectives, measures, and expectations are agreed at the outset of each engagement.",
  },
  {
    question: "How do we begin working together?",
    answer:
      "We begin with a conversation about your business needs, priorities, and desired outcomes. From there, we discuss potential opportunities, the appropriate scope, and practical next steps — with no obligation.",
  },
  {
    question: "Are your solutions standardized?",
    answer:
      "No. Our approach is based on each organization's specific challenges, objectives, and operational realities. We bring experienced practitioners and proven methods, but never a generic answer applied to every situation.",
  },
  {
    question: "Do you work with organizations outside Cleveland?",
    answer:
      "Yes. Value Based Solutions is based in Cleveland, Ohio, and works with organizations across the United States — in person where it adds value, and remotely where it makes the work more effective.",
  },
];

export function Faq() {
  const [open, setOpen] = useState<number | null>(0);

  return (
    <section id="faq" className="section-pad relative overflow-hidden bg-paper py-16 sm:py-20 md:py-28">
      <div className="shell grid gap-10 lg:grid-cols-12 lg:gap-16">
        <Reveal className="lg:col-span-4">
          <p className="eyebrow text-stone">Common questions · 05</p>
          <h2 className="display mt-5 text-[clamp(2.15rem,4.6vw,3.75rem)]">
            Questions, <em>answered.</em>
          </h2>
          <p className="mt-6 max-w-sm text-[0.9375rem] leading-relaxed text-stone">
            A few things worth knowing before we begin. If your question isn't here, a
            short conversation will usually cover it.
          </p>
          <a
            href="#contact"
            className="group mt-7 inline-flex items-center gap-2.5 text-[0.688rem] font-semibold uppercase tracking-[0.15em] text-gold-light transition hover:text-gold"
          >
            Ask us directly
            <ArrowUpRight className="h-3.5 w-3.5 transition-transform duration-300 group-hover:translate-x-0.5 group-hover:-translate-y-0.5" />
          </a>
        </Reveal>

        <Reveal variant="up" delay={120} className="lg:col-span-8">
          <div className="border-b border-gold/15">
            {QUESTIONS.map((item, index) => {
              const isOpen = open === index;
              const panelId = `faq-panel-${index}`;
              const buttonId = `faq-button-${index}`;
              return (
                <div key={item.question} className="faq-item border-t border-gold/15">
                  <h3>
                    <button
                      type="button"
                      id={buttonId}
                      aria-expanded={isOpen}
                      aria-controls={panelId}
                      onClick={() => setOpen(isOpen ? null : index)}
                      className="group flex w-full items-center justify-between gap-4 py-4 text-left sm:gap-5 sm:py-5 md:py-6"
                    >
                      <span className="flex items-baseline gap-3 sm:gap-4">
                        <span className="font-mono text-[0.65rem] tracking-[0.1em] text-gold/80">
                          {String(index + 1).padStart(2, "0")}
                        </span>
                        <span
                          className={cn(
                            "font-display text-[1.05rem] leading-snug tracking-[-0.015em] transition-colors md:text-[1.2rem]",
                            isOpen ? "text-gold-light" : "text-frost/75 group-hover:text-gold-light",
                          )}
                        >
                          {item.question}
                        </span>
                      </span>
                      <span
                        className={cn(
                          "faq-toggle inline-flex h-8 w-8 shrink-0 items-center justify-center rounded-full border",
                          isOpen
                            ? "is-open border-gold bg-ink text-frost"
                            : "border-gold/15 text-frost/50 group-hover:border-gold/40 group-hover:text-frost",
                        )}
                        aria-hidden="true"
                      >
                        <PlusIcon className="h-3.5 w-3.5" />
                      </span>
                    </button>
                  </h3>
                  <div
                    id={panelId}
                    role="region"
                    aria-labelledby={buttonId}
                    className={cn(
                      "grid transition-[grid-template-rows,opacity] duration-500 ease-[cubic-bezier(.22,1,.36,1)]",
                      isOpen ? "grid-rows-[1fr] opacity-100" : "grid-rows-[0fr] opacity-0",
                    )}
                  >
                    <div className="overflow-hidden">
                      <p className="max-w-2xl pb-6 pr-2 text-[0.875rem] leading-relaxed text-stone sm:pl-9 sm:pr-10 md:pb-7">
                        {item.answer}
                      </p>
                    </div>
                  </div>
                </div>
              );
            })}
          </div>
        </Reveal>
      </div>
    </section>
  );
}
