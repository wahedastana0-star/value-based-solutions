import { ArrowUpRight, MapPinIcon } from "@/components/Icons";
import { LogoMark } from "@/components/Logo";
import { ParallaxLayer, Reveal, Stagger, WordReveal } from "@/components/Motion";

const PRINCIPLES = [
  {
    index: "01",
    title: "Measurable results",
    text: "Business outcomes that matter — improving performance, managing costs, and creating value you can point to.",
  },
  {
    index: "02",
    title: "Practical solutions",
    text: "Complex challenges translated into clear, actionable solutions designed for real-world execution.",
  },
  {
    index: "03",
    title: "Business-focused strategy",
    text: "Sourcing, operations, supply chain, and technology decisions aligned to your business priorities.",
  },
];

const QUOTE = [
  { text: "“Value" },
  { text: "is" },
  { text: "not" },
  { text: "a" },
  { text: "presentation." },
  { text: "It" },
  { text: "is" },
  { text: "a" },
  { text: "business" },
  { text: "outcome.”", accent: true },
];

export function About() {
  return (
    <section id="about" className="section-pad relative overflow-hidden bg-paper pb-16 pt-4 sm:pb-20 md:pb-28">
      <div className="shell">
        <div className="grid items-start gap-12 lg:grid-cols-12 lg:gap-16">
          <div className="lg:col-span-6 lg:sticky lg:top-28">
            <Reveal>
              <p className="eyebrow text-stone">About us · 02</p>
              <h2 className="display mt-5 text-[clamp(2.15rem,5vw,4rem)]">
                Clear thinking. Practical solutions. <em className="text-gold">Meaningful value.</em>
              </h2>
            </Reveal>

            <Reveal delay={120} className="mt-7 max-w-lg space-y-5 text-[0.9375rem] leading-relaxed text-stone">
              <p>
                Value Based Solutions is a management consulting firm focused on improving
                overall business performance. We connect each engagement to the levers that
                influence revenue, profitability, or cost.
              </p>
              <p>
                Our approach combines experienced professionals, rigorous analysis, and
                methodologies tailored to the realities of each organization — not a generic
                answer applied to every challenge.
              </p>
            </Reveal>

            <Stagger className="mt-9 divide-y divide-gold/15 border-y border-gold/15" delay={120}>
              {PRINCIPLES.map((principle) => (
                <div
                  key={principle.index}
                  className="group grid grid-cols-[auto_1fr] gap-4 py-4 transition-colors duration-300 hover:bg-gold/[0.05] md:gap-6"
                >
                  <span className="pt-1 font-mono text-[0.65rem] tracking-[0.12em] text-gold">
                    {principle.index}
                  </span>
                  <div>
                    <h3 className="font-sans text-[0.83rem] font-semibold uppercase tracking-[0.1em] text-gold-light">
                      {principle.title}
                    </h3>
                    <p className="mt-1.5 max-w-md text-[0.83rem] leading-relaxed text-stone">
                      {principle.text}
                    </p>
                  </div>
                </div>
              ))}
            </Stagger>

            <Reveal delay={200}>
              <a href="#contact" className="btn btn-ink mt-9">
                Work with us
                <ArrowUpRight className="h-3.5 w-3.5" />
              </a>
            </Reveal>
          </div>

          <Reveal
            variant="up"
            delay={140}
            className="media-reveal relative lg:col-span-5 lg:col-start-8"
          >
            <figure className="relative">
              <div className="media-frame relative h-[360px] overflow-hidden rounded-t-[7rem] rounded-b-2xl border border-gold/25 sm:h-[440px] sm:rounded-t-[9rem] md:h-[560px] md:rounded-t-[10rem]">
                <ParallaxLayer strength={20} scale={1.14}>
                  <img
                    src="https://images.pexels.com/photos/16543939/pexels-photo-16543939.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=1300&w=900"
                    alt="Curved glass high-rise lit with warm golden bands against a deep blue evening sky"
                    loading="lazy"
                    className="h-full w-full object-cover brightness-[1.12] saturate-[1.02]"
                  />
                </ParallaxLayer>
                <div className="absolute inset-0 bg-ink/15 mix-blend-multiply" aria-hidden="true" />
                <div className="absolute inset-0 bg-linear-to-t from-ink/90 via-ink/10 to-transparent" />
                <div className="absolute inset-x-0 bottom-0 z-10 p-6 text-frost md:p-8">
                  <div className="mb-4 h-px w-12 origin-left bg-gold transition-transform duration-700 group-hover:w-20" />
                  <p className="font-display text-[1.35rem] leading-tight tracking-[-0.02em] md:text-[1.6rem]">
                    Structure creates clarity.
                    <br />
                    Clarity creates value.
                  </p>
                </div>
              </div>

              <div className="absolute left-4 top-24 z-20 flex items-center gap-2 rounded-full border border-gold/35 bg-[#081a38]/85 px-3 py-2 shadow-[0_16px_32px_-24px_rgba(0,0,0,.8)] backdrop-blur sm:left-5 sm:top-28">
                <LogoMark tone="dark" className="h-4 w-4" />
                <span className="text-[0.65rem] font-semibold uppercase tracking-[0.16em] text-gold-light">
                  The value mark
                </span>
              </div>

              <div className="mt-4 flex flex-col items-start gap-1.5 sm:flex-row sm:items-center sm:justify-between sm:gap-3">
                <span className="inline-flex items-center gap-2 text-[0.62rem] uppercase leading-relaxed tracking-[0.1em] text-stone sm:text-[0.65rem] sm:tracking-[0.14em]">
                  <MapPinIcon className="h-3.5 w-3.5 shrink-0 text-gold" />
                  Cleveland, Ohio · Serving the U.S.
                </span>
                <span className="hidden font-mono text-[0.65rem] uppercase tracking-[0.14em] text-stone/70 sm:block">
                  Est. advisory
                </span>
              </div>
              <figcaption className="sr-only">
                A modern architectural facade with repeating geometric forms.
              </figcaption>
            </figure>
          </Reveal>
        </div>
      </div>
    </section>
  );
}

export function Perspective() {
  return (
    <section className="grain relative overflow-hidden border-y border-gold/15 bg-[#0b2245] py-12 text-frost sm:py-16 md:py-20">
      <div className="pointer-events-none absolute inset-0 grid-lines opacity-50" aria-hidden="true" />
      <div className="shell relative z-10 grid gap-8 lg:grid-cols-12 lg:items-center">
        <Reveal className="lg:col-span-9">
          <span className="mb-6 block h-px w-16 origin-left bg-gold rule-draw" aria-hidden="true" />
          <blockquote className="display on-dark max-w-4xl text-[clamp(1.65rem,4.6vw,3.5rem)] leading-[1.08]">
            <WordReveal words={QUOTE} />
          </blockquote>
        </Reveal>
        <Reveal
          variant="left"
          delay={240}
          className="flex items-center gap-4 lg:col-span-3 lg:justify-end"
        >
          <LogoMark tone="dark" className="logo-mark h-9 w-9" />
          <div className="h-9 w-px bg-[#0b2245]/20" />
          <p className="max-w-[18ch] text-[0.688rem] uppercase leading-relaxed tracking-[0.13em] text-frost/50">
            The work starts with the decision — not the deck.
          </p>
        </Reveal>
      </div>
    </section>
  );
}
