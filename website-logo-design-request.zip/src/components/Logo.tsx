import { MARK, markPalette, type Tone } from "@/lib/brand";
import { cn } from "@/utils/cn";

type MarkProps = {
  tone?: Tone;
  className?: string;
  title?: string;
};

/** The Value Mark — two converging paths, the gold edge rising above the evidence. */
export function LogoMark({ tone = "light", className, title }: MarkProps) {
  const palette = markPalette(tone);
  return (
    <svg
      viewBox={MARK.viewBox}
      role={title ? "img" : undefined}
      aria-hidden={title ? undefined : true}
      className={cn("logo-mark block h-10 w-10 shrink-0", className)}
      fill="none"
    >
      {title ? <title>{title}</title> : null}
      <path d={MARK.left} fill={palette.left} />
      <path d={MARK.right} fill={palette.right} />
    </svg>
  );
}

export function LogoMonogram({
  tone = "dark",
  className,
}: {
  tone?: "dark" | "light";
  className?: string;
}) {
  const onDark = tone === "dark";
  return (
    <span
      className={cn(
        "inline-flex items-center justify-center rounded-[26%] shadow-[0_18px_40px_-24px_rgba(0,0,0,0.7)]",
        onDark ? "bg-ink" : "bg-[#0b2245]",
        className ?? "h-12 w-12",
      )}
    >
      <LogoMark
        tone={onDark ? "dark" : "light"}
        className="h-[64%] w-[64%]"
      />
    </span>
  );
}

type LockupProps = {
  tone?: Tone;
  stacked?: boolean;
  size?: "sm" | "md" | "lg";
  className?: string;
  markClassName?: string;
  labelClassName?: string;
  showRule?: boolean;
};

const LOCKUP_SIZES = {
  sm: {
    mark: "h-8 w-8",
    top: "text-[0.65rem] tracking-[0.22em]",
    sub: "text-[0.5rem] tracking-[0.36em]",
    gap: "mt-1.5",
  },
  md: {
    mark: "h-9 w-9 md:h-10 md:w-10",
    top: "text-[0.68rem] tracking-[0.24em] md:text-[0.7rem]",
    sub: "text-[0.6rem] tracking-[0.4em]",
    gap: "mt-1.5",
  },
  lg: {
    mark: "h-14 w-14 md:h-16 md:w-16",
    top: "text-[1rem] tracking-[0.26em] md:text-[1.15rem]",
    sub: "text-[0.68rem] tracking-[0.46em] md:text-[0.75rem]",
    gap: "mt-2.5",
  },
} as const;

export function LogoLockup({
  tone = "light",
  stacked = false,
  size = "md",
  className,
  markClassName,
  labelClassName,
  showRule = false,
}: LockupProps) {
  const textTone = tone === "dark" ? "text-frost" : "text-frost";
  const subTone = tone === "dark" ? "text-frost/55" : "text-stone";
  const scale = LOCKUP_SIZES[size];

  if (stacked) {
    return (
      <span className={cn("inline-flex flex-col items-center text-center", className)}>
        <LogoMark
          tone={tone}
          className={cn(size === "lg" ? "h-20 w-20" : "h-12 w-12", markClassName)}
        />
        <span className={cn("mt-4 flex flex-col items-center", textTone, labelClassName)}>
          <span className={cn("font-semibold uppercase leading-none", size === "lg" ? "text-[1rem] tracking-[0.3em]" : "text-[0.7rem] tracking-[0.28em]")}>
            Value Based
          </span>
          <span className={cn("font-medium uppercase leading-none", size === "lg" ? "text-[0.75rem] tracking-[0.44em]" : "text-[0.6rem] tracking-[0.42em]", subTone, "mt-2")}>
            Solutions
          </span>
        </span>
        {showRule ? <span className={cn("h-px bg-gold/80", size === "lg" ? "mt-6 w-20" : "mt-5 w-14")} /> : null}
      </span>
    );
  }

  return (
    <span className={cn("inline-flex items-center gap-3", className)}>
      <LogoMark tone={tone} className={cn(scale.mark, markClassName)} />
      <span className={cn("flex flex-col", textTone, labelClassName)}>
        <span className={cn("whitespace-nowrap font-semibold uppercase leading-none", scale.top)}>
          Value Based
        </span>
        <span className={cn("whitespace-nowrap font-medium uppercase leading-none", scale.sub, scale.gap, subTone)}>
          Solutions
        </span>
      </span>
    </span>
  );
}

/** Rotating stamp used as a brand detail. */
export function BrandSeal({ className }: { className?: string }) {
  return (
    <svg viewBox="0 0 120 120" className={cn("h-24 w-24", className)} aria-hidden="true">
      <defs>
        <path
          id="seal-path"
          d="M60,60 m-44,0 a44,44 0 1,1 88,0 a44,44 0 1,1 -88,0"
        />
      </defs>
      <g className="seal-spin">
        <circle cx="60" cy="60" r="57" fill="none" stroke="currentColor" strokeOpacity="0.22" />
        <text
          fill="currentColor"
          fontSize="8.4"
          letterSpacing="2.9"
          fontFamily="Inter, sans-serif"
          fontWeight="500"
        >
          <textPath href="#seal-path" startOffset="0%">
            EVIDENCE · ALIGNMENT · EXECUTION ·
          </textPath>
        </text>
      </g>
      <circle cx="60" cy="60" r="33" fill="none" stroke="currentColor" strokeOpacity="0.15" />
      <g transform="translate(42 42) scale(0.75)">
        <path d={MARK.left} fill="#EBD9A8" />
        <path d={MARK.right} fill="#C9A24B" />
      </g>
    </svg>
  );
}
