import { Header } from "@/components/Header";
import { Hero, LeverMarquee } from "@/components/Hero";
import { Services } from "@/components/Services";
import { About, Perspective } from "@/components/About";
import { Approach } from "@/components/Approach";
import { Briefs } from "@/components/Briefs";
import { Faq } from "@/components/Faq";
import { Contact } from "@/components/Contact";
import { Footer } from "@/components/Footer";
import { useRevealOnScroll, useScrollProgress } from "@/hooks/useSite";

export default function App() {
  useRevealOnScroll();
  const progress = useScrollProgress();

  return (
    <div className="min-h-screen bg-paper">
      <a
        href="#main"
        className="sr-only z-[80] focus:not-sr-only focus:fixed focus:left-4 focus:top-4 focus:rounded-full focus:bg-gold focus:px-5 focus:py-3 focus:text-[0.7rem] focus:font-semibold focus:uppercase focus:tracking-[0.14em] focus:text-ink"
      >
        Skip to content
      </a>

      <div
        className="fixed inset-x-0 top-0 z-[65] h-[2px] origin-left bg-gold transition-transform duration-150 ease-out"
        style={{ transform: `scaleX(${progress})` }}
        aria-hidden="true"
      />

      <Header />

      <main id="main">
        <Hero />
        <LeverMarquee />
        <Services />
        <About />
        <Perspective />
        <Approach />
        <Briefs />
        <Faq />
        <Contact />
      </main>

      <Footer />
    </div>
  );
}
